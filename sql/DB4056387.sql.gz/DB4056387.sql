-- MySQL dump 10.13  Distrib 5.6.45, for Linux (x86_64)
--
-- Host: nana.store.d0m.de    Database: DB4056387
-- ------------------------------------------------------
-- Server version	5.6.42-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) COLLATE latin1_german1_ci NOT NULL,
  `password` varchar(255) COLLATE latin1_german1_ci DEFAULT NULL,
  `pwset` tinyint(1) NOT NULL,
  `firstname` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `surname` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_german1_ci NOT NULL,
  `rights` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'Basti0307','$2y$10$lvvsNEf1t423OHfNg75/F.kqXh27Lz6rcf7M1XjWT8kqflhWB5cmO',1,'Bastian','Schneider','bastian@7sprojekt.de',3),(2,'testuser1','$2y$10$jDybFnZQs9XlOq0PThFcTuPiFFRWBmmssOdtYP9W7T/cIx3PwuJIm',1,'test','test','test@lagertest.de',1),(3,'testuser2','$2y$10$4Z26MXvRjoFcFN1iVWF2cuANYfzfJU2II252H61gfjtiDmzjVYK7O',0,'test','test','test@test.de',2),(4,'testuser3','$2y$10$.IEylWct8zz9IqP/S6Oze.bobMZ5xKaO.pknv.hKjV89TSY8EoXSq',0,'test','test','test@test.de',3);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_anmeldedaten`
--

DROP TABLE IF EXISTS `tbl_anmeldedaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_anmeldedaten` (
  `TeilnehmerID` varchar(15) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `Schwimmer` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Schwimmstufe` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Badeerlaubnis` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Springen` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Ernaehrung` varchar(1000) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Krankheit` varchar(1000) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Medikamente` varchar(1000) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Taschengeld` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Versicherung_art` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Versicherung_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `KFZ` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Ratenzahlung` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Raten_anzahl` varchar(2) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `zahlungsdaten` varchar(100) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Shirts` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Shirts_anzahl` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Shirts_groesse` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `umfrage` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `art` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Datum` date DEFAULT NULL,
  `IP_Adresse` varchar(45) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  PRIMARY KEY (`TeilnehmerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_anmeldedaten`
--

LOCK TABLES `tbl_anmeldedaten` WRITE;
/*!40000 ALTER TABLE `tbl_anmeldedaten` DISABLE KEYS */;
INSERT INTO `tbl_anmeldedaten` VALUES ('5f1359fa2469b','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,NULL,'online','2020-07-18','2003:e2:ff0e:9b00:a1d3:6023:3e5d:81a7'),('5f199ff175925','ja','bronze','ja','ja','dsfsdf','dsfsdfffffffffffffffffffffffffffffffffff sd sdf sdf s','df dsfffffffffffffffff sdf we ffffffffsd fwe fsdaf e saf ','ja','gesetzlich','Barmer','ja','nein',NULL,NULL,'ja','2','L',NULL,'online','2020-07-23','2003:e2:ff0e:9b00:b53b:ad28:74ed:d914'),('5f19dcba61d24','nein',NULL,'nein','ja','Ist natÃ¼rlich nur Salat, strenger veganer','Maximale Dummheit','Ein Bong Hit pro Tag reicht','nein','privat','Sowas hat der nicht','ja','ja','3',NULL,'ja','5','134/140',NULL,'online','2020-07-23','2003:e2:ff0e:9b00:b53b:ad28:74ed:d914'),('5f19dd84e8470','ja','Waal','ja','nein','Er ist nur Waalfleisch.','nein','Viagra','nein','privat','Hallschen','ja','nein',NULL,NULL,'ja','5','L',NULL,'online','2020-07-23','2003:e2:ff0e:9b00:b53b:ad28:74ed:d914'),('5f2c31c3274df','ja','','ja','ja','','','','ja','gesetzlich','Barmer','ja','nein',NULL,NULL,'nein',NULL,NULL,NULL,'online','2020-08-06','2003:e2:ff0b:2200:39a7:574c:c6e4:fc06'),('5f2d74c77a398','ja','gold','ja','ja','','','','nein','gesetzlich','Barmer','ja','nein','',NULL,'ja','1','S',NULL,'analog','2020-08-07','1'),('5f359e0f295e5','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein','',NULL,'ja','1','L',NULL,'analog','2020-08-13','1'),('5f359eb95e0e5','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,NULL,'online','2020-08-13','2003:e2:ff0b:2200:e823:c464:c1f5:2a4a'),('5f35a15332118','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,NULL,'online','2020-08-13','2003:e2:ff0b:2200:e823:c464:c1f5:2a4a'),('5f35a30c00b76','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','ja','',NULL,'ja','','',NULL,'analog','2020-08-13','1'),('5f35a4d19f4c6','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,NULL,'online','2020-08-13','2003:e2:ff0b:2200:e823:c464:c1f5:2a4a'),('5f3a86d9e6c9f','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,'teilnehmer','online','2020-08-17','2003:e2:ff14:8d00:f49e:180c:2949:1c65'),('5f3d980033138','nein','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein','','350','ja','1','M','analog','analog','2020-08-19','1'),('5f4533b277120','ja','','ja','ja','','','','ja','gesetzlich','Barmer','ja','nein',NULL,'340','ja','1','M','keine_angaben','online','2020-08-25','2003:e2:ff15:cb00:b162:de3d:9ed4:a026'),('5f4584a3b68c8','ja','','ja','ja','','','','ja','gesetzlich','AOK','ja','nein',NULL,NULL,'nein',NULL,NULL,'keine_angaben','online','2020-08-25','2003:e2:ff25:2200:b162:de3d:9ed4:a026');
/*!40000 ALTER TABLE `tbl_anmeldedaten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_historie`
--

DROP TABLE IF EXISTS `tbl_historie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_historie` (
  `id` varchar(15) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `jahr` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `vorname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `nachname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `geschlecht` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `lageralter` int(2) NOT NULL,
  `schwimmer` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `badeerlaubnis` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `springen` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `ernaehrung` varchar(1000) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `taschengeld` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `kfz` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `ratenzahlung` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `shirts` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `shirts_anzahl` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `shirts_groesse` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `umfrage` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `art` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `datum` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_historie`
--

LOCK TABLES `tbl_historie` WRITE;
/*!40000 ALTER TABLE `tbl_historie` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbl_historie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_srgb`
--

DROP TABLE IF EXISTS `tbl_srgb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_srgb` (
  `TeilnehmerID` varchar(15) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `e_Nachname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL DEFAULT '',
  `e_Vorname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL DEFAULT '',
  `Strasse` varchar(100) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `PLZ` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Ort` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Tel_pri` varchar(20) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Tel_handy` varchar(20) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Tel_dienstl` varchar(20) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `email` varchar(320) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `mitglied` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `mitarbeiter` varchar(5) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  PRIMARY KEY (`TeilnehmerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_srgb`
--

LOCK TABLES `tbl_srgb` WRITE;
/*!40000 ALTER TABLE `tbl_srgb` DISABLE KEYS */;
INSERT INTO `tbl_srgb` VALUES ('5f1359fa2469b','Schneider','Sven','Heinrich-von-Kleist-Str.','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','nein'),('5f199ff175925','kevin','kavin','Heinrich-von-Kleist-Str.8','15711','KÃ¶nigs Wusterhausen','015229536902','+49 15615498','84126156/7841231','bastian@7sprojekt.de','ja','ja'),('5f19dcba61d24','Schmidt','Rene','Am Hang 13','15711','KÃ¶nigs Wusterhausen','045611651','','','faustan1000@live.de','nein','nein'),('5f19dd84e8470','Neumann','Sabine','Am WindmÃ¼hlenberg 15','15711','KÃ¶nigs Wusterhausen','017315561','','','lukasneumann92@gmail.com','nein','nein'),('5f2c31c3274df','Schneider','Bastian','Heinrich-von-Kleist-Str.8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','ja'),('5f2d74c77a398','Schneider','Sven','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhausen','015229536902','015229536902','015229536902','bastian@7sprojekt.de','ja','nein'),('5f359e0f295e5','Schneider','Sven','Heinrich-von-Kleist-Str., 8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','ja','nein'),('5f359eb95e0e5','Schneider','Svenneuneu','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','ja','nein'),('5f35a15332118','Schneide','Sveni','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','ja','nein'),('5f35a30c00b76','Schneide','Sven','Heinrich-von-Kleist-Str., 8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','nein'),('5f35a4d19f4c6','Schneide','Sven','Heinrich-von-Kleist-Str.','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','ja'),('5f3a86d9e6c9f','Schneider','Sven','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','nein'),('5f3d980033138','Schneider','Bianka','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhausen','015229536902','','','bastian@7sprojekt.de','nein','nein'),('5f4533b277120','Schneider','Sven','Heinrich-von-Kleist-Str. 8','15711','KÃ¶nigs Wusterhause','','','','bastian@7sprojekt.de','nein','nein'),('5f4584a3b68c8','Schneider','Sven','Heinrich-von-Kleist-Str. 28','15711','KÃ¶nigs Wusterhausen','','','','bastian@7sprojekt.de','nein','nein');
/*!40000 ALTER TABLE `tbl_srgb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_stammdaten`
--

DROP TABLE IF EXISTS `tbl_stammdaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_stammdaten` (
  `TeilnehmerID` varchar(15) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `Nachname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Vorname` varchar(50) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Geschlecht` varchar(10) CHARACTER SET utf8 COLLATE utf8_german2_ci DEFAULT NULL,
  `Geburtstag` date DEFAULT NULL,
  `LagerAlter` int(2) DEFAULT NULL,
  `Jahr` varchar(10) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`TeilnehmerID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_stammdaten`
--

LOCK TABLES `tbl_stammdaten` WRITE;
/*!40000 ALTER TABLE `tbl_stammdaten` DISABLE KEYS */;
INSERT INTO `tbl_stammdaten` VALUES ('5f1359fa2469b','Bastian','Schneider','maennlich','2010-07-03',10,'2020\n'),('5f199ff175925','Kevin','Kevin','maennlich','2006-07-03',14,'2020\n'),('5f19dcba61d24','William','Schmidt','maennlich','2006-01-03',14,'2020\n'),('5f19dd84e8470','Lukas','Neumann','maennlich','2006-06-14',14,'2020\n'),('5f2c31c3274df','Super','Sauer','weiblich','2011-07-03',9,'2020\n'),('5f2d74c77a398','Schneider','Bianka','weiblich','2011-03-31',9,'2020\n'),('5f359e0f295e5','Schneider','Bastianneu','maennlich','2011-07-03',9,'2020\n'),('5f359eb95e0e5','Bastianneuneu','Schneider','maennlich','2011-07-03',9,'0'),('5f35a15332118','Schneide','Bastian','maennlich','2009-07-03',11,'2020\n'),('5f35a30c00b76','Schneide','Bastiane','maennlich','2011-07-03',9,'2020\n'),('5f35a4d19f4c6','Schneider','Bastian','maennlich','2008-07-03',12,'2020\n'),('5f3a86d9e6c9f','Schneider','Batsian','weiblich','2008-07-03',12,'2020\n'),('5f3d980033138','Schneider','Bastitest','maennlich','2008-07-03',12,'2020\n'),('5f4533b277120','Schneider','Bauer','maennlich','2010-07-03',10,'2020\n'),('5f4584a3b68c8','Schneider','Bastian','maennlich','2010-07-03',10,'2020\n');
/*!40000 ALTER TABLE `tbl_stammdaten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voranmeldung`
--

DROP TABLE IF EXISTS `voranmeldung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voranmeldung` (
  `email` varchar(300) CHARACTER SET utf8 COLLATE utf8_german2_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voranmeldung`
--

LOCK TABLES `voranmeldung` WRITE;
/*!40000 ALTER TABLE `voranmeldung` DISABLE KEYS */;
INSERT INTO `voranmeldung` VALUES ('bastian@7sprojekt.de','2020-05-28 11:39:00');
/*!40000 ALTER TABLE `voranmeldung` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-04 12:07:39
